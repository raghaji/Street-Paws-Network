package org.raghaji.street_paw_network.models;

public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
  }
