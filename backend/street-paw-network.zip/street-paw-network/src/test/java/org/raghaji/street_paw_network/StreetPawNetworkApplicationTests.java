package org.raghaji.street_paw_network;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StreetPawNetworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
